#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define SUCCESS 0
#define FAILURE -1

// Doubly linked list node for digits
typedef struct Dlist
{
    int data;
    struct Dlist *prev;
    struct Dlist *next;
} Dlist;

// ---------------------- Function Prototypes ----------------------

// Argument validation
int read_and_validate_args(int argc, char *argv[], Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, char **operator);

// Linked list helpers
void insert_at_tail(Dlist **head, Dlist **tail, int digit);
void insert_at_head(Dlist **head, Dlist **tail, int digit);
void print_list(Dlist *head);



/* Arithmetic operations */

 // Addition
void add_lists(Dlist *head1, Dlist *tail1, Dlist *head2, Dlist *tail2, Dlist **res_head, Dlist **res_tail);


// Substraction
void subtract_lists(Dlist *larger_head, Dlist *larger_tail, Dlist *smaller_head, Dlist *smaller_tail, Dlist **res_head, Dlist **res_tail);


// Multiplication
void multiply_by_digit(Dlist *larger_tail, int digit, int shift, Dlist **res_head, Dlist **res_tail);

void multiply_lists(Dlist *larger_head, Dlist *larger_tail, Dlist *smaller_head, Dlist *smaller_tail, Dlist **res_head, Dlist **res_tail);


// Division
int is_zero(Dlist *head, Dlist *tail);

int compare_lists(Dlist *head1, Dlist *tail1, Dlist *head2, Dlist *tail2);

void copy_list(Dlist *src_head, Dlist *src_tail, Dlist **dest_head, Dlist **dest_tail);

int divide_lists(Dlist *dividend_head, Dlist *dividend_tail, Dlist *divisor_head, Dlist *divisor_tail, Dlist **result_head, Dlist **result_tail);

void free_list(Dlist **head, Dlist **tail);

#endif 