#include "main.h"

#define RED     "\033[1;31m"   // Defining colour codes
#define GREEN   "\033[1;32m"
#define BLUE    "\033[34m"
#define RESET   "\033[0m"

int read_and_validate_args(int argc, char *argv[], Dlist **head2, Dlist **tail2, Dlist **head1, Dlist **tail1, char **operator)
{
    if (argc != 4)
    {
        printf(BLUE "Usage: %s <num1> <operator> <num2>\n" RESET, argv[0]);
        return FAILURE;
    }

    if(argv[1] == NULL)
    {
        printf(RED "Operand 1 not passed\n" RESET);
        return FAILURE;
    }

    if(argv[2] == NULL)
    {
        printf(RED "Operator not passed\n" RESET);
        return FAILURE;
    }

    if(argv[3] == NULL)
    {
        printf(RED "Operand 2 not passed\n" RESET);
        return FAILURE;
    }

    char *operand1 = argv[1];
    *operator = argv[2];
    char *operand2 = argv[3];

    // Validate operator
    if (!(strcmp(*operator, "+") == 0 ||
          strcmp(*operator, "-") == 0 ||
          strcmp(*operator, "*") == 0 ||
          strcmp(*operator, "/") == 0))
    {
        printf(RED "Invalid operator: %s\n" RESET, *operator);
        return FAILURE;
    }

    // Validate operand1 and operand2
    for (int i = 0; operand1[i] != '\0'; i++) {
        if (i == 0 && operand1[i] == '-') {
           // allow leading minus sign
           continue;
        }
        if (!isdigit((unsigned char)operand1[i])) {
            printf("Invalid character in operand1: %c\n", operand1[i]);
            return FAILURE;
        }
        insert_at_tail(head1, tail1, operand1[i] - '0');
    }

    for (int i = 0; operand2[i] != '\0'; i++) {
        if (i == 0 && operand2[i] == '-') {
           // allow leading minus sign
           continue;
        }
        if (!isdigit((unsigned char)operand2[i])) {
            printf("Invalid character in operand2: %c\n", operand2[i]);
            return FAILURE;
        }
        insert_at_tail(head2, tail2, operand2[i] - '0');
    }

    return SUCCESS;
}

// Insert digit at tail
void insert_at_tail(Dlist **head, Dlist **tail, int digit)
{
    Dlist *new = malloc(sizeof(Dlist));
    if (!new)
    {
        printf(RED "Memory allocation failed\n" RESET);
        exit(1);
    }

    new->data = digit;
    new->next = NULL;
    new->prev = *tail;

    if (*tail) 
    {
        (*tail)->next = new;
    } 
    else 
    {
        *head = new; // first node in the list
    }

    *tail = new;
}

// Insert digit at head
void insert_at_head(Dlist **head, Dlist **tail, int digit)
{
    Dlist *new = malloc(sizeof(Dlist));
    if (!new)
    {
        printf(RED "Memory allocation failed\n" RESET);
        exit(1);
    }

    new->data = digit;
    new->prev = NULL;
    new->next = *head;

    if (*head) 
    {
        (*head)->prev = new;
    } 
    else 
    {
        *tail = new; // first node in the list
    }

    *head = new;
}

// Print list
void print_list(Dlist *head)
{
    Dlist *temp = head;
    printf(BLUE "Head -> " RESET);
    while (temp)
    {
        printf("%d", temp->data);
        if (temp->next)
            printf(" <-> ");
        temp = temp->next;
    }
    printf(BLUE " <- Tail\n" RESET);
}

// Addition 
void add_lists(Dlist *head1, Dlist *tail1,
               Dlist *head2, Dlist *tail2,
               Dlist **res_head, Dlist **res_tail)
{
    Dlist *p1 = tail1;
    Dlist *p2 = tail2;
    int carry = 0;

    while (p1 != NULL || p2 != NULL || carry != 0)
    {
        int d1 = (p1 != NULL) ? p1->data : 0;
        int d2 = (p2 != NULL) ? p2->data : 0;

        int sum = d1 + d2 + carry;
        int digit = sum % 10;
        carry = sum / 10;

        insert_at_head(res_head, res_tail, digit);

        if (p1) 
        p1 = p1->prev;
        if (p2) 
        p2 = p2->prev;
    }
}

// Substraction 
void subtract_lists(Dlist *larger_head, Dlist *larger_tail,
                    Dlist *smaller_head, Dlist *smaller_tail,
                    Dlist **res_head, Dlist **res_tail)
{
    Dlist *p1 = larger_tail;
    Dlist *p2 = smaller_tail;
    int borrow = 0;

    while (p1 != NULL || p2 != NULL)
    {
        int d1 = (p1 != NULL) ? p1->data : 0;
        int d2 = (p2 != NULL) ? p2->data : 0;

        d1 = d1 - borrow;

        if (d1 < d2)
        {
            d1 = d1 + 10;
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }

        int diff = d1 - d2;
        insert_at_head(res_head, res_tail, diff);

        if (p1) 
        p1 = p1->prev;
        if (p2) 
        p2 = p2->prev;
    }

    // Remove leading zeros
    while (*res_head && (*res_head)->data == 0 && (*res_head)->next != NULL)
    {
        Dlist *temp = *res_head;
        *res_head = (*res_head)->next;
        (*res_head)->prev = NULL;
        free(temp);
    }
}

void multiply_lists(Dlist *larger_head, Dlist *larger_tail,
                    Dlist *smaller_head, Dlist *smaller_tail,
                    Dlist **res_head, Dlist **res_tail)
{
    Dlist *p2 = smaller_tail;
    int shift = 0;

    while (p2 != NULL)
    {
        Dlist *temp_head = NULL, *temp_tail = NULL;
        int carry = 0;
        Dlist *p1 = larger_tail;

        // multiply larger by one digit of smaller
        while (p1 != NULL || carry != 0)
        {
            int d1 = (p1 != NULL) ? p1->data : 0;
            int prod = d1 * p2->data + carry;
            int digit = prod % 10;
            carry = prod / 10;

            insert_at_head(&temp_head, &temp_tail, digit);

            if (p1) 
            p1 = p1->prev;
        }

        // add shift zeros 
        for (int i = 0; i < shift; i++)
            insert_at_tail(&temp_head, &temp_tail, 0);

        // add partial product to result
        if (*res_head == NULL)
        {
            // first partial product becomes result
            *res_head = temp_head;
            *res_tail = temp_tail;
        }
        else
        {
            Dlist *sum_head = NULL, *sum_tail = NULL;
            add_lists(*res_head, *res_tail, temp_head, temp_tail,
                      &sum_head, &sum_tail);

            // free old result and temp
            free_list(res_head, res_tail);
            free_list(&temp_head, &temp_tail);

            // update result
            *res_head = sum_head;
            *res_tail = sum_tail;
        }

        shift++;
        p2 = p2->prev;
    }
}

//Division
int compare_lists(Dlist *head1, Dlist *tail1,
                  Dlist *head2, Dlist *tail2)
{
    // Find lengths
    int len1 = 0, len2 = 0;
    Dlist *temp1 = head1, *temp2 = head2;

    while (temp1) 
    { 
        len1++; 
        temp1 = temp1->next; 
    }
    while (temp2) 
    { 
        len2++; 
        temp2 = temp2->next; 
    }

    // Compare lengths 
    if (len1 > len2) 
       return 1;
    else if (len1 < len2) 
       return -1;

    // Lengths equal, compare digit by digit
    temp1 = head1;
    temp2 = head2;
    while (temp1 && temp2)
    {
        if (temp1->data > temp2->data) 
           return 1;
        else if (temp1->data < temp2->data) 
           return -1;

        temp1 = temp1->next;
        temp2 = temp2->next;
    }

    return 0; // equal
}

void copy_list(Dlist *src_head, Dlist *src_tail,
               Dlist **dest_head, Dlist **dest_tail)
{
    *dest_head = NULL;
    *dest_tail = NULL;

    Dlist *temp = src_head;
    while (temp)
    {
        Dlist *new_node = malloc(sizeof(Dlist));
        if (!new_node)
        {
            printf(RED "Memory allocation failed in copy_list\n" RESET);
            return;
        }

        new_node->data = temp->data;
        new_node->next = NULL;
        new_node->prev = NULL;

        if (*dest_head == NULL)
        {
            *dest_head = new_node;
            *dest_tail = new_node;
        }
        else
        {
            (*dest_tail)->next = new_node;
            new_node->prev = *dest_tail;
            *dest_tail = new_node;
        }

        temp = temp->next;
    }
}

int is_zero(Dlist *head, Dlist *tail)
{
    // Empty list is not valid
    if (head == NULL) 
    return 0;

    // Skip leading zeros
    Dlist *temp = head;
    while (temp && temp->data == 0) 
    {
        temp = temp->next;
    }

    return (temp == NULL);
}

int divide_lists(Dlist *dividend_head, Dlist *dividend_tail,
                 Dlist *divisor_head, Dlist *divisor_tail,
                 Dlist **result_head, Dlist **result_tail)
{
    Dlist *quot_head = NULL, *quot_tail = NULL;
    insert_at_tail(&quot_head, &quot_tail, 0);

    // Increment value (1)
    Dlist *one_head = NULL, *one_tail = NULL;
    insert_at_tail(&one_head, &one_tail, 1);

    // Copy dividend
    Dlist *temp_div_head = NULL, *temp_div_tail = NULL;
    copy_list(dividend_head, dividend_tail, &temp_div_head, &temp_div_tail);

    // Repeated subtraction until dividend < divisor
    while (compare_lists(temp_div_head, temp_div_tail, divisor_head, divisor_tail) >= 0)
    {
        Dlist *new_div_head = NULL, *new_div_tail = NULL;
        subtract_lists(temp_div_head, temp_div_tail,
                       divisor_head, divisor_tail,
                       &new_div_head, &new_div_tail);

        free_list(&temp_div_head, &temp_div_tail);
        temp_div_head = new_div_head;
        temp_div_tail = new_div_tail;

        Dlist *new_head = NULL, *new_tail = NULL;
        add_lists(quot_head, quot_tail,
                  one_head, one_tail,
                  &new_head, &new_tail);

        free_list(&quot_head, &quot_tail);
        quot_head = new_head;
        quot_tail = new_tail;

        // printf("result: ");
        // print_list(temp_div_head);
        // printf("\n");

    }

    free_list(&one_head, &one_tail);
    free_list(&temp_div_head, &temp_div_tail);

    *result_head = quot_head;
    *result_tail = quot_tail;

    return SUCCESS;
}

void free_list(Dlist **head, Dlist **tail)
{
    Dlist *temp = *head;
    while (temp)
    {
        Dlist *next = temp->next;
        free(temp);
        temp = next;
    }
    *head = NULL;
    *tail = NULL;
}