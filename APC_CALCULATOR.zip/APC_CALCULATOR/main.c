#include "main.h"

#define RED     "\033[1;31m"   // Defining colour codes
#define GREEN   "\033[1;32m"
#define BLUE    "\033[34m"
#define RESET   "\033[0m"

// Global flags
int flag1 = 0; // operand1 larger
int flag2 = 0; // operand2 larger
int flag3 = 0; // operands equal

// Helper: check larger
void check_larger(Dlist *head1, Dlist *tail1, Dlist *head2, Dlist *tail2)
{
    flag1 = flag2 = flag3 = 0;
    int cmp = compare_lists(head1, tail1, head2, tail2);
    if (cmp > 0) flag1 = 1;
    else if (cmp < 0) flag2 = 1;
    else flag3 = 1;
}

// Helper: detect negative
int is_negative(char *operand)
{
    return (operand[0] == '-') ? 1 : 0;
}

int main(int argc, char *argv[])
{
    Dlist *head1 = NULL, *tail1 = NULL;
    Dlist *head2 = NULL, *tail2 = NULL;
    Dlist *res_head = NULL, *res_tail = NULL;
    char *operator = NULL;
    int is_neg1 = 0, is_neg2 = 0, is_result_neg = 0;

    // Read and validate arguments
    if (read_and_validate_args(argc, argv, &head1, &tail1, &head2, &tail2, &operator) == FAILURE)
    {
        return 1;
    }

    operator = argv[2];
    is_neg1 = is_negative(argv[1]);
    is_neg2 = is_negative(argv[3]);

    // Print operands
    printf(GREEN "Operand1:\n" RESET);
    print_list(head1);

    printf(GREEN "Operand2:\n" RESET);
    print_list(head2);

    // Perform operation using switch-case
    switch (operator[0])
    {
        case '+':
            if (is_neg1 && is_neg2) 
            {
                add_lists(head1, tail1, head2, tail2, &res_head, &res_tail);
                is_result_neg = 1;
            }
            else if (is_neg1 && !is_neg2) 
            {
                check_larger(head1, tail1, head2, tail2);
                if (flag1) { subtract_lists(head1, tail1, head2, tail2, &res_head, &res_tail); is_result_neg = 1; }
                else if (flag2) { subtract_lists(head2, tail2, head1, tail1, &res_head, &res_tail); is_result_neg = 0; }
                else { insert_at_head(&res_head, &res_tail, 0); is_result_neg = 0; }
            }
            else if (!is_neg1 && is_neg2) 
            {
                check_larger(head1, tail1, head2, tail2);
                if (flag1) { subtract_lists(head1, tail1, head2, tail2, &res_head, &res_tail); is_result_neg = 0; }
                else if (flag2) { subtract_lists(head2, tail2, head1, tail1, &res_head, &res_tail); is_result_neg = 1; }
                else { insert_at_head(&res_head, &res_tail, 0); is_result_neg = 0; }
            }
            else 
            {
                add_lists(head1, tail1, head2, tail2, &res_head, &res_tail);
                is_result_neg = 0;
            }
            // printf(GREEN "Result:\n" RESET);
            // print_result(res_head, is_result_neg);
            break;

            case '-':
            if (is_neg1 && is_neg2) 
            {
                // -a - (-b) = b - a
                check_larger(head1, tail1, head2, tail2);
                if (flag1) { subtract_lists(head1, tail1, head2, tail2, &res_head, &res_tail); is_result_neg = 1; }
                else if (flag2) { subtract_lists(head2, tail2, head1, tail1, &res_head, &res_tail); is_result_neg = 0; }
                else { insert_at_head(&res_head, &res_tail, 0); is_result_neg = 0; }
            }
            else if (is_neg1 && !is_neg2) 
            
            {
                // -a - b = -(a + b)
                add_lists(head1, tail1, head2, tail2, &res_head, &res_tail);
                is_result_neg = 1;
            }
            else if (!is_neg1 && is_neg2) 
            
            {
                // a - (-b) = a + b
                add_lists(head1, tail1, head2, tail2, &res_head, &res_tail);
                is_result_neg = 0;
            }
            else 
            
            {
                check_larger(head1, tail1, head2, tail2);
                if (flag1) { subtract_lists(head1, tail1, head2, tail2, &res_head, &res_tail); is_result_neg = 0; }
                else if (flag2) { subtract_lists(head2, tail2, head1, tail1, &res_head, &res_tail); is_result_neg = 1; }
                else { insert_at_head(&res_head, &res_tail, 0); is_result_neg = 0; }
            }
            // printf(GREEN "Result:\n" RESET);
            // print_result(res_head, is_result_neg);
            break;

        case '*':
            multiply_lists(head1, tail1, head2, tail2, &res_head, &res_tail);
            is_result_neg = (is_neg1 ^ is_neg2);
            // printf(GREEN "Result:\n" RESET);
            // print_result(res_head, is_result_neg);
            break;

        case '/':
            if (is_zero(head2, tail2)) 
            {
                printf(RED "Invalid: Division by zero\n" RESET);
                break;
            }
            check_larger(head1, tail1, head2, tail2);
            if (flag1) 
            {
                divide_lists(head1, tail1, head2, tail2, &res_head, &res_tail);
                is_result_neg = (is_neg1 ^ is_neg2);
            }
            else if (flag2) 
            {
                insert_at_head(&res_head, &res_tail, 0);
                is_result_neg = 0;
            }
            else 
            {
                insert_at_head(&res_head, &res_tail, 1);
                is_result_neg = (is_neg1 ^ is_neg2);
            }
            // printf(GREEN "Result:\n" RESET);
            // print_result(res_head, is_result_neg);
            break;

            default:
                printf(RED "Unsupported operator '%s'.\n" RESET, operator);
                break;
        }
        if (is_result_neg && res_head) {
        res_head->data *= -1;
    }

    printf(GREEN "Result:\n" RESET);
    print_list(res_head);

    return 0;
}